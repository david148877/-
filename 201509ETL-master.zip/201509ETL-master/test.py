a = 30
b = 2

print  a + b